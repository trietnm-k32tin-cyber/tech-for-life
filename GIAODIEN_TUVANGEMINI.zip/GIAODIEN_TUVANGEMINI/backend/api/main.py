from contextlib import asynccontextmanager
import datetime
import json
import os
import random
import string
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from google import genai
from google.genai import types
import joblib
import numpy as np
import openvino as ov
from pydantic import BaseModel

from api.schemas import (
    ChatRequest,
    GeminiAdviceRequest,
    GeminiAdviceResponse,
    PredictionRequest,
    PredictionResponse,
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from supabase import Client, create_client

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Đường dẫn đến thư mục chứa 10-Fold Models và Scalers
OPENVINO_DIR = os.path.join(BASE_DIR, 'model_artifacts', 'openvino_ir_models')
SCALERS_DIR = os.path.join(BASE_DIR, 'model_artifacts', 'scalers')
MEDICAL_KB_PATH = os.path.join(BASE_DIR, 'medical_kb.json')

SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')
supabase: Client = None

if SUPABASE_URL and SUPABASE_KEY:
  try:
    supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
  except Exception as e:
    print(f'❌ Lỗi Supabase: {e}')

# Khai báo biến toàn cục cho 10-Fold Ensemble
COMPILED_MODELS = []
SCALERS = []
N_SPLITS = 10

MEDICAL_KB = []
VECTORIZER = None
MEDICAL_KB_MATRIX = None


def generate_unique_user_code() -> str:
  """Sinh mã người dùng duy nhất gồm 5 ký tự viết hoa/số (VD: HS-A8K92)"""
  while True:
    code = 'HS-' + ''.join(
        random.choices(string.ascii_uppercase + string.digits, k=5)
    )
    if supabase:
      try:
        res = (
            supabase.table('users')
            .select('user_code')
            .eq('user_code', code)
            .execute()
        )
        if not res.data:
          return code
      except Exception:
        return code
    else:
      return code


@asynccontextmanager
async def lifespan(app: FastAPI):
  global COMPILED_MODELS, SCALERS, MEDICAL_KB, VECTORIZER, MEDICAL_KB_MATRIX
  print('🚀 Đang khởi tạo hệ thống 10-Fold OpenVINO Ensemble & RAG Y Khoa...')

  try:
    core = ov.Core()
    COMPILED_MODELS = []
    SCALERS = []

    # Nạp 10 mô hình OpenVINO và 10 Scaler tương ứng
    loaded_folds = 0
    for fold in range(1, N_SPLITS + 1):
      xml_path = os.path.join(OPENVINO_DIR, f'fnn_model_fold_{fold}.xml')
      scaler_path = os.path.join(SCALERS_DIR, f'scaler_fold_{fold}.pkl')

      # Kiểm tra đường dẫn dự phòng nếu người dùng giải nén trực tiếp vào BASE_DIR
      if not os.path.exists(xml_path):
        xml_path = os.path.join(
            BASE_DIR, 'openvino_ir_models', f'fnn_model_fold_{fold}.xml'
        )
      if not os.path.exists(scaler_path):
        scaler_path = os.path.join(
            BASE_DIR, 'scalers', f'scaler_fold_{fold}.pkl'
        )

      if os.path.exists(xml_path) and os.path.exists(scaler_path):
        compiled_model = core.compile_model(model=xml_path, device_name='CPU')
        scaler = joblib.load(scaler_path)

        COMPILED_MODELS.append(compiled_model)
        SCALERS.append(scaler)
        loaded_folds += 1

    if loaded_folds == N_SPLITS:
      print(
          f'✅ Đã tải thành công trọn bộ {N_SPLITS}-Fold OpenVINO Ensemble &'
          ' Scalers!'
      )
    else:
      print(f'⚠️ Cảnh báo: Chỉ nạp được {loaded_folds}/{N_SPLITS} folds.')

    # Tải Kho tri thức Y khoa
    if os.path.exists(MEDICAL_KB_PATH):
      with open(MEDICAL_KB_PATH, 'r', encoding='utf-8') as f:
        MEDICAL_KB = json.load(f)

      corpus = [f"{item['title']} {item['content']}" for item in MEDICAL_KB]
      VECTORIZER = TfidfVectorizer()
      MEDICAL_KB_MATRIX = VECTORIZER.fit_transform(corpus)
      print('✅ Đã index thành công kho tri thức Y khoa RAG!')

  except Exception as e:
    print(f'❌ Lỗi khởi tạo Lifespan: {e}')

  yield
  print('Tắt Server...')


app = FastAPI(
    title='Smartphone Addiction RAG OpenVINO Ensemble API',
    version='4.5.0',
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


class AuthCodeRequest(BaseModel):
  user_code: str | None = None
  name: str | None = None
  school: str | None = None
  grade: str | None = None
  gender: str | None = None


# --- 1. API ĐĂNG NHẬP / ĐĂNG KÝ MÃ NGƯỜI DÙNG ---
@app.post('/api/auth/code')
async def handle_user_code(req: AuthCodeRequest):
  if not supabase:
    raise HTTPException(status_code=500, detail='Chưa kết nối CSDL Supabase')

  try:
    if req.user_code and req.user_code.strip():
      clean_code = req.user_code.strip().upper()
      user_res = (
          supabase.table('users')
          .select('*')
          .eq('user_code', clean_code)
          .execute()
      )
      if not user_res.data:
        raise HTTPException(
            status_code=404, detail='Mã người dùng không tồn tại!'
        )

      user_info = user_res.data[0]
      history_res = (
          supabase.table('survey_results')
          .select('*')
          .eq('user_code', clean_code)
          .order('created_at', desc=False)
          .execute()
      )

      return {
          'is_new': False,
          'user_info': user_info,
          'session_history': history_res.data or [],
          'total_sessions': len(history_res.data or []),
      }
    else:
      if not req.name or not req.school:
        raise HTTPException(
            status_code=400, detail='Vui lòng cung cấp Họ tên và Trường học.'
        )

      new_code = generate_unique_user_code()
      new_user = {
          'user_code': new_code,
          'name': req.name,
          'school': req.school,
          'grade': req.grade or '11',
          'gender': req.gender or 'Nam',
          'created_at': datetime.datetime.now().isoformat(),
      }
      supabase.table('users').insert(new_user).execute()
      return {
          'is_new': True,
          'user_info': new_user,
          'session_history': [],
          'total_sessions': 0,
      }
  except HTTPException as http_ex:
    raise http_ex
  except Exception as err:
    print(f'❌ Lỗi xử lý user_code: {err}')
    raise HTTPException(status_code=500, detail=f'Lỗi Server: {str(err)}')


# --- 2. THỐNG KÊ LƯỢT NGƯỜI DÙNG ---
@app.get('/api/stats')
async def get_stats():
  total_users = 0
  if supabase:
    try:
      res = (
          supabase.table('survey_results').select('id', count='exact').execute()
      )
      total_users = res.count if res.count is not None else 0
    except Exception as e:
      print(f'❌ Lỗi đếm số lượng survey_results: {e}')
  return {'total_users': total_users}


# --- 3. DỰ ĐOÁN MỨC ĐỘ VỚI 10-FOLD OPENVINO ENSEMBLE ---
@app.post('/api/predict', response_model=PredictionResponse)
async def predict_addiction(request: PredictionRequest):
  tong_diem = sum([
      request.Q1,
      request.Q2,
      request.Q3,
      request.Q4,
      request.Q5,
      request.Q6,
      request.Q7,
      request.Q8,
      request.Q9,
      request.Q10,
  ])

  # 1. Tính toán 3 đặc trưng Feature Engineering (Q_mean, Q_std, Q_max)
  q_list = [
      request.Q1,
      request.Q2,
      request.Q3,
      request.Q4,
      request.Q5,
      request.Q6,
      request.Q7,
      request.Q8,
      request.Q9,
      request.Q10,
  ]
  q_mean = float(np.mean(q_list))
  q_std = float(np.std(q_list))
  q_max = float(np.max(q_list))

  # 2. Xây dựng vector 14 đặc trưng đúng thứ tự đã huấn luyện
  # Format: ['tg_sudung_dt', 'Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9', 'Q10', 'Q_mean', 'Q_std', 'Q_max']
  raw_vector = np.array(
      [[
          request.tg_sudung_dt,
          request.Q1,
          request.Q2,
          request.Q3,
          request.Q4,
          request.Q5,
          request.Q6,
          request.Q7,
          request.Q8,
          request.Q9,
          request.Q10,
          q_mean,
          q_std,
          q_max,
      ]],
      dtype=np.float32,
  )

  predicted_class = 1
  total_probs = np.zeros((1, 3))

  # 3. Chạy suy luận tích lũy trên cả 10 Fold
  if len(COMPILED_MODELS) > 0 and len(SCALERS) > 0:
    try:
      num_models = len(COMPILED_MODELS)
      for i in range(num_models):
        compiled_model = COMPILED_MODELS[i]
        scaler = SCALERS[i]

        scaled_vector = scaler.transform(raw_vector).astype(np.float32)
        output_layer = compiled_model.output(0)
        fold_prob = compiled_model([scaled_vector])[output_layer]

        total_probs += fold_prob / num_models

      predicted_class = int(np.argmax(total_probs, axis=1)[0])
    except Exception as e:
      print(f'❌ Lỗi suy luận 10-Fold OpenVINO Ensemble: {e}')
  else:
    # Rule-based dự phòng nếu chưa nạp được mô hình
    if tong_diem <= 20:
      predicted_class = 0
    elif tong_diem <= 35:
      predicted_class = 1
    else:
      predicted_class = 2

  mapping = {0: 'Thấp', 1: 'Trung bình', 2: 'Cao'}
  result_str = mapping.get(predicted_class, 'Trung bình')

  # Tính độ tin cậy thực tế từ xác suất các lớp
  low_conf = float(round(total_probs[0][0], 4)) if len(COMPILED_MODELS) > 0 else 0.33
  med_conf = float(round(total_probs[0][1], 4)) if len(COMPILED_MODELS) > 0 else 0.34
  high_conf = float(round(total_probs[0][2], 4)) if len(COMPILED_MODELS) > 0 else 0.33

  advice_map = {
      'Thấp': (
          'Bạn đang quản lý thời gian dùng thiết bị rất tốt. Hãy duy trì thói'
          ' quen lành mạnh này!'
      ),
      'Trung bình': (
          'Bạn có nguy cơ chớm phụ thuộc vào điện thoại. Hãy chú ý tiết chế và'
          ' phân bổ thời gian nghỉ ngơi.'
      ),
      'Cao': (
          'Bạn đang ở mức độ nguy cơ cao! Cần áp dụng ngay các biện pháp kiểm'
          ' soát thời gian màn hình nghiêm ngặt.'
      ),
  }

  raw_code = getattr(request, 'user_code', None)
  clean_user_code = (
      raw_code.strip().upper() if (raw_code and raw_code.strip()) else None
  )

  # Lưu kết quả vào Supabase
  if supabase:
    try:
      supabase.table('survey_results').insert({
          'user_code': clean_user_code,
          'name': request.name,
          'Truong': request.Truong,
          'Khoi': request.Khoi,
          'Phai': request.Phai,
          'tg_sudung_dt': request.tg_sudung_dt,
          'Tong': tong_diem,
          'addiction': predicted_class,
          'Level': predicted_class,
          'Q1': request.Q1,
          'Q2': request.Q2,
          'Q3': request.Q3,
          'Q4': request.Q4,
          'Q5': request.Q5,
          'Q6': request.Q6,
          'Q7': request.Q7,
          'Q8': request.Q8,
          'Q9': request.Q9,
          'Q10': request.Q10,
          'created_at': datetime.datetime.now().isoformat(),
      }).execute()
    except Exception as e:
      print(f'⚠️ Lỗi lưu bảng survey_results: {e}')

  return PredictionResponse(
      predicted_level=predicted_class,
      confidence_scores={'Thấp': low_conf, 'Trung bình': med_conf, 'Cao': high_conf},
      result=result_str,
      advice=advice_map[result_str],
  )


# --- 4. PHÂN TÍCH YẾU TỐ ẢNH HƯỞNG & RAG ---
def analyze_feature_contributions(input_features_dict):
  """Phân tích các đặc trưng ảnh hưởng lớn nhất đến nguy cơ nghiện"""
  q_list = [int(input_features_dict.get(f'Q{i}', 0)) for i in range(1, 11)]
  tg_sudung = float(
      input_features_dict.get(
          'tg_sudung_dt', input_features_dict.get('hours', 0)
      )
  )

  causes = []
  if tg_sudung >= 5.0:
    causes.append(
        f'Thời gian sử dụng điện thoại rất dài ({tg_sudung} giờ/ngày)'
    )

  if input_features_dict.get('Q8', 0) >= 4:
    causes.append('Thói quen liên tục kiểm tra điện thoại vì sợ bỏ lỡ tin nhắn')
  if input_features_dict.get('Q9', 0) >= 4:
    causes.append('Sử dụng điện thoại vượt quá mốc thời gian dự định')
  if input_features_dict.get('Q4', 0) >= 4:
    causes.append('Cảm giác bứt rứt, khó chịu khi không có điện thoại bên cạnh')
  if input_features_dict.get('Q7', 0) >= 4:
    causes.append('Không thể dừng sử dụng dù biết đã ảnh hưởng tới học tập')
  if input_features_dict.get('Q3', 0) >= 4:
    causes.append('Đau mỏi cổ hoặc tay do dùng thiết bị quá lâu')

  if not causes:
    causes = [
        f'Thời gian màn hình {tg_sudung}h/ngày',
        'Cần quản lý tốt hơn thời gian dùng mạng xã hội và giải trí',
    ]

  return causes[:3]


def retrieve_medical_docs(query_text: str, top_k: int = 2):
  if len(MEDICAL_KB) == 0 or VECTORIZER is None or MEDICAL_KB_MATRIX is None:
    return []

  query_vec = VECTORIZER.transform([query_text])
  similarities = cosine_similarity(query_vec, MEDICAL_KB_MATRIX)[0]
  top_k_indices = np.argsort(similarities)[::-1][:top_k]

  return [MEDICAL_KB[idx] for idx in top_k_indices]


# --- 5. TƯ VẤN GEMINI AI ---
@app.post('/api/gemini-advice', response_model=GeminiAdviceResponse)
async def get_gemini_advice(request: GeminiAdviceRequest):
  api_key = os.getenv('GEMINI_API_KEY')
  if not api_key:
    raise HTTPException(
        status_code=500, detail='Chưa cấu hình GEMINI_API_KEY trên máy chủ.'
    )

  try:
    current_client = genai.Client(api_key=api_key)
  except Exception as e:
    raise HTTPException(
        status_code=500, detail=f'Không thể khởi tạo Gemini Client: {e}'
    )

  survey_data = request.survey_data or {}
  survey_data['tg_sudung_dt'] = request.hours
  shap_causes = analyze_feature_contributions(survey_data)

  query_for_rag = (
      f'Nghiện điện thoại {request.result_level}. Tác nhân: '
      + ', '.join(shap_causes)
  )
  retrieved_medical_chunks = retrieve_medical_docs(query_for_rag, top_k=2)
  medical_texts = [
      f"[{doc['title']}]: {doc['content']}" for doc in retrieved_medical_chunks
  ]

  progress_summary = 'ĐÂY LÀ LẦN KHẢO SÁT ĐẦU TIÊN CỦA HỌC SINH NÀY.'
  raw_code = getattr(request, 'user_code', None)
  clean_user_code = (
      raw_code.strip().upper() if (raw_code and raw_code.strip()) else None
  )

  if clean_user_code and supabase:
    try:
      history_res = (
          supabase.table('survey_results')
          .select('*')
          .eq('user_code', clean_user_code)
          .order('created_at', desc=False)
          .execute()
      )

      sessions = history_res.data or []
      if len(sessions) > 1:
        progress_summary = (
            f'LỊCH SỬ TIẾN TRÌNH ({len(sessions)} LẦN KHẢO SÁT):\n'
        )
        level_map = {0: 'Thấp', 1: 'Trung bình', 2: 'Cao'}
        for idx, sess in enumerate(sessions[:-1], 1):
          lvl_str = level_map.get(sess.get('addiction', 1), 'Trung bình')
          progress_summary += (
              f"- Lần {idx} ({str(sess.get('created_at', ''))[:10]}):"
              f" {sess.get('tg_sudung_dt', 0)}h/ngày | Điểm:"
              f" {sess.get('Tong', 0)} | Mức độ: {lvl_str}\n"
          )

        curr = sessions[-1]
        prev = sessions[-2]
        hours_diff = float(curr.get('tg_sudung_dt', 0)) - float(
            prev.get('tg_sudung_dt', 0)
        )
        score_diff = int(curr.get('Tong', 0)) - int(prev.get('Tong', 0))
        progress_summary += (
            f'\nSO SÁNH VỚI LẦN GẦN NHẤT: Thời gian dùng {hours_diff:+.1f}'
            f' giờ/ngày, tổng điểm nguy cơ {score_diff:+} điểm.'
        )
    except Exception as e:
      print(f'⚠️ Lỗi đọc lịch sử Supabase: {e}')

  prompt = f"""
    Bạn là một Chuyên gia Tâm lý học Lâm sàng và Hành vi số Y khoa. Hãy đưa ra tư vấn chuyên sâu dựa trên dữ liệu chẩn đoán, tiến trình biến đổi và tài liệu y khoa.

    --- HỒ SƠ HỌC SINH ---
    - Tên: {request.name} | Giới tính: {request.gender} | Học sinh khối: {request.grade}
    - Thời gian sử dụng hiện tại: {request.hours} giờ/ngày
    - Kết quả phân tích nguy cơ: {request.result_level}

    --- PHÂN TÍCH TIẾN TRÌNH DÀI HẠN (MULTI-SESSION MEMORY) ---
    {progress_summary}

    --- NGUYÊN NHÂN CỐT LÕI TỪ DỮ LIỆU CẢNH BÁO ---
    * {shap_causes[0]}
    * {shap_causes[1] if len(shap_causes) > 1 else ''}

    --- TÀI LIỆU Y KHOA TRÍCH XUẤT TỪ RAG ---
    {json.dumps(medical_texts, ensure_ascii=False, indent=2)}

    --- YÊU CẦU ĐẦU RA ---
    Trả về đúng cấu trúc JSON gồm các trường:
    1. "analysis": Phân tích nguyên nhân hành vi và ĐÁNH GIÁ SỰ TIẾN BỘ / THAY ĐỔI so với các lần khảo sát trước.
    2. "shap_root_causes": Danh sách 2-3 nguyên nhân chính.
    3. "medical_references": Danh sách tóm tắt ngắn các căn cứ y khoa đã dùng.
    4. "solutions": 3 giải pháp hành vi thực tế, có tính kế thừa cho học sinh khối {request.grade}.
    5. "parent_message": Lời khuyên tinh tế gửi đến phụ huynh.
    """

  try:
    response = current_client.models.generate_content(
        model='gemini-2.5-flash',
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type='application/json',
            response_schema=GeminiAdviceResponse,
            temperature=0.6,
        ),
    )
    return json.loads(response.text)
  except Exception as e:
    print(f'❌ Lỗi Gọi Gemini API: {str(e)}')
    raise HTTPException(status_code=500, detail=f'Lỗi Gemini API: {str(e)}')


# --- 6. PHẢN HỒI VÀ LƯU VÀO BẢNG training_data VÀ prompt_reviews ---
class SaveTrainingRequest(BaseModel):
  user_code: str | None = None
  rating: int
  feedback_text: str | None = None
  survey_data: dict
  pred_class: int
  total_score: int
  advice_data: dict | None = None


@app.post('/api/save-training')
async def save_training_data(request: SaveTrainingRequest):
  global MEDICAL_KB, VECTORIZER, MEDICAL_KB_MATRIX

  raw_code = request.user_code
  clean_user_code = (
      raw_code.strip().upper() if (raw_code and raw_code.strip()) else None
  )
  survey = request.survey_data or {}

  if supabase:
    data_to_insert = {
        'user_code': clean_user_code,
        'name': survey.get('name'),
        'Truong': survey.get('school') or survey.get('Truong'),
        'Khoi': str(survey.get('grade') or survey.get('Khoi') or '11'),
        'Phai': survey.get('gender') or survey.get('Phai'),
        'tg_sudung_dt': float(
            survey.get('hours') or survey.get('tg_sudung_dt') or 0
        ),
        'Q1': int(survey.get('Q1', 0)),
        'Q2': int(survey.get('Q2', 0)),
        'Q3': int(survey.get('Q3', 0)),
        'Q4': int(survey.get('Q4', 0)),
        'Q5': int(survey.get('Q5', 0)),
        'Q6': int(survey.get('Q6', 0)),
        'Q7': int(survey.get('Q7', 0)),
        'Q8': int(survey.get('Q8', 0)),
        'Q9': int(survey.get('Q9', 0)),
        'Q10': int(survey.get('Q10', 0)),
        'Tong': int(request.total_score),
        'addiction': int(request.pred_class),
        'Level': int(request.pred_class),
        'rating': int(request.rating),
        'feedback_text': request.feedback_text,
        'created_at': datetime.datetime.now().isoformat(),
    }
    try:
      supabase.table('training_data').insert(data_to_insert).execute()
    except Exception as e:
      print(f'❌ Lỗi lưu training_data: {e}')

  if request.rating == 5 and request.advice_data:
    try:
      solutions = request.advice_data.get('solutions', [])
      solutions_str = (
          '; '.join(solutions)
          if isinstance(solutions, list)
          else str(solutions)
      )

      new_case_study = {
          'id': f'case_{int(datetime.datetime.now().timestamp())}',
          'feature_target': 'successful_case_study',
          'title': (
              'Case Study Thành Công - Học sinh'
              f" {survey.get('name', 'Ẩn danh')}"
          ),
          'content': (
              f'Giải pháp hiệu quả đã áp dụng: {solutions_str}. Phản hồi:'
              f" {request.feedback_text or 'Rất hài lòng'}"
          ),
      }

      MEDICAL_KB.append(new_case_study)
      with open(MEDICAL_KB_PATH, 'w', encoding='utf-8') as f:
        json.dump(MEDICAL_KB, f, ensure_ascii=False, indent=2)

      corpus = [f"{item['title']} {item['content']}" for item in MEDICAL_KB]
      VECTORIZER = TfidfVectorizer()
      MEDICAL_KB_MATRIX = VECTORIZER.fit_transform(corpus)
      print('✅ [RAG Auto-Learn] Đã nạp thành công Case Study 5 sao vào RAG!')
    except Exception as e:
      print(f'❌ Lỗi tự động nạp RAG: {e}')

  if request.rating <= 2 and supabase:
    try:
      supabase.table('prompt_reviews').insert({
          'user_code': clean_user_code,
          'rating': request.rating,
          'feedback_text': request.feedback_text,
          'survey_data': request.survey_data,
          'advice_given': request.advice_data,
          'created_at': datetime.datetime.now().isoformat(),
      }).execute()
      print('⚠️ [Prompt Review] Đã lưu đánh giá 1-2 sao vào prompt_reviews!')
    except Exception as e:
      print(f'❌ Lỗi lưu prompt_reviews: {e}')

  return {'status': 'success', 'message': 'Đã ghi nhận phản hồi thành công!'}


@app.get('/api/admin/reviews')
async def get_flagged_reviews():
  if not supabase:
    raise HTTPException(status_code=500, detail='Chưa kết nối Supabase')
  try:
    res = (
        supabase.table('prompt_reviews')
        .select('*')
        .order('created_at', desc=True)
        .execute()
    )
    return {'total': len(res.data or []), 'reviews': res.data or []}
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


# --- 7. CHATBOT GEMINI ---
@app.post('/api/gemini-chat')
async def gemini_chat(request: ChatRequest):
  api_key = os.getenv('GEMINI_API_KEY')
  if not api_key:
    return {'reply': 'Tôi chưa sẵn sàng trả lời do thiếu GEMINI_API_KEY.'}

  try:
    chat_client = genai.Client(api_key=api_key)
    context_str = ''
    if request.context:
      context_str = (
          f'Học sinh có mức nguy cơ: {request.context.result_level}, dùng'
          f' {request.context.hours}h/ngày.'
      )

    prompt = f"""
        Bạn là một Chuyên gia Tâm lý AI thân thiện.
        Bối cảnh: {context_str}
        Học sinh nhắn: "{request.message}"
        Hãy đưa ra phản hồi ngắn gọn, ấm áp (dưới 3 câu).
        """

    response = chat_client.models.generate_content(
        model='gemini-2.5-flash',
        contents=prompt,
    )
    return {'reply': response.text}
  except Exception as e:
    print(f'❌ Lỗi Chatbot Gemini: {e}')
    return {
        'reply': (
            'Tôi đang gặp gián đoạn kết nối. Bạn vui lòng nhắn lại sau ít phút'
            ' nhé!'
        )
    }