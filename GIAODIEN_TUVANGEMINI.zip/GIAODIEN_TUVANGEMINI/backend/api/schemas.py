from pydantic import BaseModel

class PredictionRequest(BaseModel):
    user_code: str | None = None
    name: str
    Truong: str
    Khoi: str
    Phai: str
    tg_sudung_dt: float
    Q1: int
    Q2: int
    Q3: int
    Q4: int
    Q5: int
    Q6: int
    Q7: int
    Q8: int
    Q9: int
    Q10: int

class PredictionResponse(BaseModel):
    predicted_level: int
    confidence_scores: dict
    result: str
    advice: str

class GeminiAdviceRequest(BaseModel):
    user_code: str | None = None
    name: str
    gender: str
    grade: str
    hours: float
    result_level: str
    survey_data: dict | None = None

class GeminiAdviceResponse(BaseModel):
    analysis: str
    shap_root_causes: list[str]
    medical_references: list[str]
    solutions: list[str]
    parent_message: str

class ChatMessage(BaseModel):
    role: str
    text: str

class ChatContext(BaseModel):
    result_level: str
    hours: float
    symptoms: list[str] | None = None

class ChatRequest(BaseModel):
    message: str
    history: list[ChatMessage] = []
    context: ChatContext | None = None