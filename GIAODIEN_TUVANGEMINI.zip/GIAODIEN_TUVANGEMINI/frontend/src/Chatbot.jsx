 import React, { useState, useRef, useEffect } from 'react';

function Chatbot() {
  const [history, setHistory] = useState([
    { role: 'model', text: 'Chào bạn! Tôi là chuyên gia tâm lý hỗ trợ các vấn đề về sử dụng điện thoại. Bạn có điều gì muốn tâm sự hoặc cần lời khuyên thêm không?' }
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatWindowRef = useRef(null);

  // Tự động cuộn xuống tin nhắn mới nhất
  useEffect(() => {
    if (chatWindowRef.current) {
      chatWindowRef.current.scrollTop = chatWindowRef.current.scrollHeight;
    }
  }, [history]);

  const handleSend = async () => {
    if (!inputMsg.trim()) return;

    const userMessage = inputMsg;
    // Cập nhật giao diện ngay lập tức
    const currentHistory = [...history];
    setHistory([...currentHistory, { role: 'user', text: userMessage }]);
    setInputMsg('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: currentHistory.slice(1), // Không gửi câu chào mặc định lên API để tránh dư thừa
          message: userMessage
        })
      });

      if (!res.ok) throw new Error("Lỗi kết nối API");
      const data = await res.json();
      
      setHistory(prev => [...prev, { role: 'model', text: data.reply }]);
    } catch (error) {
      setHistory(prev => [...prev, { role: 'model', text: "Xin lỗi, hệ thống đang bận. Vui lòng thử lại sau nhé!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="chatbot-container ai-dashboard-section">
      <h5>💬 Trò chuyện cùng Chuyên gia AI</h5>
      
      <div className="chat-window" ref={chatWindowRef}>
        {history.map((msg, idx) => (
          <div key={idx} className={`chat-message ${msg.role}`}>
            <div className="msg-bubble">{msg.text}</div>
          </div>
        ))}
        {isLoading && (
          <div className="chat-message model">
            <div className="msg-bubble loading-dots">AI đang trả lời...</div>
          </div>
        )}
      </div>

      <div className="chat-input-area">
        <input 
          type="text" 
          value={inputMsg} 
          onChange={(e) => setInputMsg(e.target.value)} 
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Nhập câu hỏi của bạn vào đây..." 
          disabled={isLoading}
        />
        <button onClick={handleSend} disabled={isLoading || !inputMsg.trim()}>Gửi 🚀</button>
      </div>
    </div>
  );
}

export default Chatbot;