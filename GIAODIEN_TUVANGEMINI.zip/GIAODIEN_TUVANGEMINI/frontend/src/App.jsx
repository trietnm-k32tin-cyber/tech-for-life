import React, { useState, useEffect } from 'react';
import GeminiAdvice from './GeminiAdvice';
import './App.css';

const QUESTIONS = [
  "Bỏ lỡ công việc theo kế hoạch do sử dụng điện thoại thông minh.",
  "Khó tập trung trong lớp, trong khi làm bài tập hoặc trong khi làm việc do sử dụng điện thoại thông minh.",
  "Cảm thấy đau ở cổ hoặc tay sau khi sử dụng điện thoại thông minh.",
  "Sẽ không chịu đựng được nếu không có điện thoại thông minh.",
  "Cảm thấy thiếu kiên nhẫn và bực bội khi không có điện thoại thông minh.",
  "Có điện thoại thông minh trong tâm trí ngay cả khi tôi không sử dụng nó.",
  "Tôi không bao giờ từ bỏ việc sử dụng điện thoại thông minh của mình ngay cả khi cuộc sống hàng ngày của tôi đã bị ảnh hưởng rất nhiều bởi nó.",
  "Liên tục kiểm tra điện thoại thông minh của mình để không bỏ lỡ các cuộc trò chuyện giữa những người khác trên Twitter hoặc Facebook.",
  "Sử dụng điện thoại thông minh lâu hơn dự định.",
  "Những người xung quanh nói với tôi rằng tôi sử dụng điện thoại thông minh quá nhiều."
];

function App() {
  const [theme, setTheme] = useState('cream'); 
  const [step, setStep] = useState(0); 

  const [authTab, setAuthTab] = useState('login'); 
  const [userCode, setUserCode] = useState('');
  const [inputCode, setInputCode] = useState('');
  const [sessionHistory, setSessionHistory] = useState([]);
  
  const [userInfo, setUserInfo] = useState({
    name: '',
    school: '',
    grade: '11', 
    gender: 'Nam', 
    hours: 4
  });

  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(false);
  const [resultData, setResultData] = useState(null);
  const [userCount, setUserCount] = useState(0);
  const [hasRated, setHasRated] = useState(false);
  const [selectedStars, setSelectedStars] = useState(0); 

  const [geminiAdvice, setGeminiAdvice] = useState(null);
  const [geminiLoading, setGeminiLoading] = useState(false);
  const [geminiError, setGeminiError] = useState('');

  useEffect(() => {
    const fetchUserCount = async () => {
      try {
        const res = await fetch('/api/stats');
        if (res.ok) {
          const data = await res.json();
          setUserCount(data.total_users); 
        }
      } catch (error) {
        console.error("Lỗi lấy tổng số lượng người tham gia:", error);
      }
    };
    fetchUserCount();
  }, []);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const handleInfoChange = (e) => {
    const { id, value } = e.target;
    setUserInfo(prev => ({ ...prev, [id]: value }));
  };

  const handleOptionChange = (qIndex, value) => {
    setAnswers(prev => ({ ...prev, [`Q${qIndex}`]: parseInt(value) }));
  };

  const parseSafeJson = async (res) => {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch (err) {
      throw new Error(`Máy chủ gặp phản hồi lỗi (${res.status}): ${text.substring(0, 100)}`);
    }
  };

  const handleLoginWithCode = async () => {
    if (!inputCode.trim()) return alert("Vui lòng nhập mã người dùng!");
    setLoading(true);
    try {
      const res = await fetch('/api/auth/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_code: inputCode.trim() })
      });
      
      const data = await parseSafeJson(res);
      if (!res.ok) throw new Error(data.detail || "Không thể đăng nhập bằng mã này!");

      setUserCode(data.user_info.user_code);
      setUserInfo(prev => ({
        ...prev,
        name: data.user_info.name,
        school: data.user_info.school,
        grade: data.user_info.grade,
        gender: data.user_info.gender
      }));
      setSessionHistory(data.session_history || []);
      setStep(1); 
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterCode = async () => {
    if (!userInfo.name.trim() || !userInfo.school.trim()) {
      return alert("Vui lòng nhập đầy đủ Họ tên và Trường học!");
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: userInfo.name,
          school: userInfo.school,
          grade: userInfo.grade,
          gender: userInfo.gender
        })
      });

      const data = await parseSafeJson(res);
      if (!res.ok) throw new Error(data.detail || "Không thể tạo mã mới!");

      setUserCode(data.user_info.user_code);
      setSessionHistory([]);
      alert(`🎉 Đăng ký thành công! Mã người dùng của bạn là: ${data.user_info.user_code}\nHãy lưu lại mã này để đăng nhập cho các lần sau nhé.`);
      setStep(1); 
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => {
    if (step > 0 && !answers[`Q${step}`]) {
      alert("Vui lòng chọn một mức độ phù hợp với bạn!");
      return;
    }
    setStep(prev => prev + 1);
  };

  const prevStep = () => setStep(prev => (prev > 0 ? prev - 1 : 0));

  const submitSurvey = async () => {
    if (!answers[`Q10`]) {
      alert("Vui lòng chọn mức độ cho câu hỏi cuối cùng!");
      return;
    }

    setLoading(true);
    const payload = {
      user_code: userCode || null,
      name: userInfo.name,
      tg_sudung_dt: parseFloat(userInfo.hours) || 0,
      Truong: userInfo.school,
      Khoi: userInfo.grade,
      Phai: userInfo.gender,
      ...answers
    };

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

      const data = await parseSafeJson(res);
      if (data.predicted_level !== undefined) {
        setResultData(data);
        setUserCount(prev => prev + 1); 
        setStep(11); 
      }
    } catch (error) {
      console.error("Fetch Error:", error);
      setResultData({
        result: "Trung bình",
        predicted_level: 1,
        advice: "Lỗi kết nối mạng. Đây là dữ liệu dự phòng."
      });
      setStep(11);
    } finally {
      setLoading(false);
    }
  };

  const fetchGeminiAdvice = async () => {
    if (!hasRated) return;
    
    setGeminiLoading(true);
    setGeminiError('');
    try {
      const res = await fetch('/api/gemini-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_code: userCode || null,
          name: userInfo.name,
          gender: userInfo.gender,
          grade: userInfo.grade,
          hours: parseFloat(userInfo.hours) || 0,
          result_level: resultData.result,
          survey_data: {
            Tong: Object.values(answers).reduce((a, b) => a + b, 0),
            ...answers
          }
        })
      });

      if (!res.ok) throw new Error("Không thể tải lời khuyên từ hệ thống Gemini.");

      const data = await parseSafeJson(res);
      setGeminiAdvice(data);
    } catch (err) {
      console.error(err);
      setGeminiError("Không thể kết nối dịch vụ Gemini AI lúc này.");
    } finally {
      setGeminiLoading(false);
    }
  };

  const resetSurvey = () => {
    setAnswers({});
    setStep(0);
    setResultData(null);
    setGeminiAdvice(null);
    setGeminiError('');
    setHasRated(false);
    setSelectedStars(0);
  };

  const getBadgeStyle = (resultStr) => {
    const text = resultStr || '';
    if (text.includes('Cao') || text.includes('Nghiện')) {
      return { border: '2px solid #ef4444', color: '#ff6b6b', bg: 'rgba(239, 68, 68, 0.15)' };
    }
    if (text.includes('Trung bình') || text.includes('Vừa')) {
      return { border: '2px solid #f59e0b', color: '#fbbf24', bg: 'rgba(245, 158, 11, 0.15)' };
    }
    return { border: '2px solid #10b981', color: '#34d399', bg: 'rgba(16, 185, 129, 0.15)' };
  };

  return (
    <div className="app-container" data-theme={theme}>
      <button className="floating-btn theme-toggle" onClick={toggleTheme}>
        {theme === 'light' ? '🌙' : '☀️'}
      </button>

      <header className="header-section">
        <h1 className="title-main" style={{ fontSize: '2.2rem' }}>
          Smartphone Addiction
        </h1>
        <p className="subtitle" style={{ fontSize: '1.25rem', fontWeight: '600' }}>
          HỆ THỐNG DỰ ĐOÁN VÀ TƯ VẤN MỨC ĐỘ NGHIỆN SỬ DỤNG ĐIỆN THOẠI THÔNG MINH CỦA HỌC SINH THPT
        </p>

        {userCode && (
          <div style={{ marginTop: '10px' }}>
            <span style={{
              background: 'var(--panel-bg)',
              border: '1px solid rgba(79, 70, 229, 0.3)',
              padding: '6px 16px',
              borderRadius: '20px',
              fontSize: '0.9rem',
              fontWeight: '600',
              color: 'var(--primary)'
            }}>
              🔑 Mã người dùng: <strong>{userCode}</strong> ({userInfo.name})
            </span>
          </div>
        )}
      </header>

      <main className={`main-content ${geminiAdvice && step === 11 ? 'wide-layout' : ''}`}>
        
        {step < 11 && (
          <div className="card shadow-animated">
            {step === 0 && (
              <div className="fade-in">
                <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', borderBottom: '1px solid rgba(150,150,150,0.2)', paddingBottom: '10px' }}>
                  <button 
                    onClick={() => setAuthTab('login')}
                    style={{
                      flex: 1, padding: '10px', borderRadius: '10px', border: 'none', cursor: 'pointer', fontWeight: 'bold',
                      background: authTab === 'login' ? 'var(--primary)' : 'transparent',
                      color: authTab === 'login' ? '#fff' : 'var(--text-muted)'
                    }}
                  >
                    🔑 Đã có Mã (Đăng nhập)
                  </button>
                  <button 
                    onClick={() => setAuthTab('register')}
                    style={{
                      flex: 1, padding: '10px', borderRadius: '10px', border: 'none', cursor: 'pointer', fontWeight: 'bold',
                      background: authTab === 'register' ? 'var(--primary)' : 'transparent',
                      color: authTab === 'register' ? '#fff' : 'var(--text-muted)'
                    }}
                  >
                    📝 Chưa có Mã (Đăng ký mới)
                  </button>
                </div>

                {authTab === 'login' && (
                  <div>
                    <h3 className="section-title">🔑 Nhập mã người dùng của bạn</h3>
                    <div className="form-group">
                      <label>Mã người dùng (Ví dụ: HS-A8K92X)</label>
                      <input 
                        type="text" 
                        value={inputCode} 
                        onChange={(e) => setInputCode(e.target.value.toUpperCase())} 
                        placeholder="Nhập mã HS-xxxxx tại đây..." 
                      />
                    </div>
                    <div className="form-group range-group">
                      <label>Thời gian dùng điện thoại hôm nay: <strong>{userInfo.hours} giờ/ngày</strong></label>
                      <input type="range" id="hours" min="0" max="24" step="0.5" value={userInfo.hours} onChange={handleInfoChange} className="slider" />
                    </div>
                    <button className="btn-primary" onClick={handleLoginWithCode} disabled={loading}>
                      {loading ? "Đang kiểm tra mã..." : "Vào làm khảo sát 🚀"}
                    </button>
                  </div>
                )}

                {authTab === 'register' && (
                  <div>
                    <h3 className="section-title">👋 Đăng ký tạo Mã duy nhất lần đầu</h3>
                    <div className="form-group">
                      <label>Họ và tên của bạn</label>
                      <input type="text" id="name" value={userInfo.name} onChange={handleInfoChange} placeholder="Ví dụ: Nguyễn Văn A..." />
                    </div>
                    <div className="form-group">
                      <label>Trường học</label>
                      <input type="text" id="school" value={userInfo.school} onChange={handleInfoChange} placeholder="Nhập tên trường của bạn..." />
                    </div>
                    <div className="form-grid">
                      <div className="form-group">
                        <label>Khối lớp</label>
                        <select id="grade" value={userInfo.grade} onChange={handleInfoChange}>
                          <option value="10">Khối 10</option>
                          <option value="11">Khối 11</option>
                          <option value="12">Khối 12</option>
                        </select>
                      </div>
                      <div className="form-group">
                        <label>Giới tính</label>
                        <select id="gender" value={userInfo.gender} onChange={handleInfoChange}>
                          <option value="Nam">Nam</option>
                          <option value="Nữ">Nữ</option>
                        </select>
                      </div>
                    </div>
                    <div className="form-group range-group">
                      <label>Thời gian dùng điện thoại: <strong>{userInfo.hours} giờ/ngày</strong></label>
                      <input type="range" id="hours" min="0" max="24" step="0.5" value={userInfo.hours} onChange={handleInfoChange} className="slider" />
                    </div>
                    <button className="btn-primary" onClick={handleRegisterCode} disabled={loading}>
                      {loading ? "Đang tạo mã duy nhất..." : "Tạo Mã & Bắt Đầu Khảo Sát 🚀"}
                    </button>
                  </div>
                )}

              </div>
            )}

            {step >= 1 && step <= 10 && (
              <div className="fade-in question-container">
                <span className="question-counter">Câu hỏi {step} / {QUESTIONS.length}</span>
                <h2 className="question-text">{QUESTIONS[step - 1]}</h2>
                
                <div className="options-wrapper">
                  <span className="label-hint left">Rất không đồng ý</span>
                  <div className="options-flex">
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <label key={num} className={`option-card ${answers[`Q${step}`] === num ? 'selected' : ''}`}>
                        <input 
                          type="radio" 
                          name={`Q${step}`} 
                          value={num} 
                          checked={answers[`Q${step}`] === num}
                          onChange={() => handleOptionChange(step, num)} 
                        />
                        <span className="num-text">{num}</span>
                      </label>
                    ))}
                  </div>
                  <span className="label-hint right">Rất đồng ý</span>
                </div>

                <div className="nav-buttons">
                  <button className="btn-secondary" onClick={prevStep}>Quay lại</button>
                  {step < 10 ? (
                    <button className="btn-primary" onClick={nextStep}>Tiếp theo ➡️</button>
                  ) : (
                    <button className="btn-accent" onClick={submitSurvey} disabled={loading}>
                      {loading ? "Mô hình đang tính toán..." : "Xem Kết Quả 🧠"}
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {step === 11 && resultData && (
          <div className="fade-in result-page-container">
            {!geminiAdvice && (
              <div className="card text-center standard-result-view">
                <div className="success-icon">🎯</div>
                <h3>Kết quả phân tích của {userInfo.name}</h3>
                <p className="school-tag">Trường: {userInfo.school} - Khối {userInfo.grade}</p>
                
                {userCode && (
                  <div style={{ background: 'rgba(79, 70, 229, 0.08)', padding: '12px', borderRadius: '12px', margin: '15px 0', textAlign: 'left' }}>
                    <p style={{ margin: '0 0 5px 0', fontWeight: 'bold', color: 'var(--primary)', fontSize: '0.9rem' }}>
                      🔑 Mã cá nhân: <span style={{ background: '#4f46e5', color: '#fff', padding: '2px 8px', borderRadius: '6px' }}>{userCode}</span>
                    </p>
                    <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                      📊 Số lần làm khảo sát tích lũy: <strong>{sessionHistory.length + 1} lần</strong>
                    </p>
                  </div>
                )}

                <div 
                  className="result-badge-custom-fix"
                  style={{
                    padding: '14px 28px', borderRadius: '12px', display: 'inline-block', margin: '18px 0',
                    fontWeight: '800', fontSize: '1.4rem', textTransform: 'uppercase',
                    border: getBadgeStyle(resultData.result).border,
                    color: getBadgeStyle(resultData.result).color,
                    backgroundColor: getBadgeStyle(resultData.result).bg
                  }}
                >
                  Mức độ: {resultData.result} {resultData.result?.toLowerCase().includes('cao') && '(Nghiện)'}
                </div>
                
                <p className="advice-box">💡 <strong>Lời khuyên cơ bản:</strong> {resultData.advice}</p>
                
                <div className="feedback-container" style={{ margin: '25px 0', padding: '18px', background: 'rgba(255,255,255,0.04)', borderRadius: '12px' }}>
                  <p style={{ fontWeight: '600', marginBottom: '12px' }}>
                    Đánh giá mức độ hài lòng với kết quả <span style={{color: '#ff6b6b'}}>*</span>
                  </p>
                  <div className="star-flex" style={{ display: 'flex', justifyContent: 'center', gap: '12px' }}>
                    {[1, 2, 3, 4, 5].map((num) => (
                      <span 
                        key={num} 
                        style={{ 
                          fontSize: '2.3rem', cursor: hasRated ? 'not-allowed' : 'pointer',
                          color: (selectedStars >= num) ? '#fbbf24' : '#4b5563'
                        }}
                        onMouseEnter={() => !hasRated && setSelectedStars(num)}
                        onClick={async () => {
                          if (hasRated) return;
                          setHasRated(true);
                          setSelectedStars(num);
                        }}
                      >
                        ★
                      </span>
                    ))}
                  </div>
                  {hasRated && <p style={{ fontSize: '0.9rem', color: '#10b981', marginTop: '10px' }}>✅ Đã xác nhận đánh giá thành công!</p>}
                </div>

                <div className="gemini-trigger-zone-block" style={{ display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'center' }}>
                  {!geminiLoading && (
                    <button 
                      className="btn-primary gemini-btn" 
                      onClick={fetchGeminiAdvice}
                      disabled={!hasRated}
                      style={{ width: '100%', maxWidth: '360px', opacity: hasRated ? 1 : 0.4 }}
                    >
                      ✨ Nhận lời khuyên chuyên sâu từ Gemini AI {!hasRated && '🔒'}
                    </button>
                  )}

                  {geminiLoading && (
                    <div className="ai-loading-card">
                      <div className="magic-spinner">🔮</div>
                      <p>Gemini AI đang phân tích sâu dữ liệu lịch sử & RAG Y Khoa...</p>
                    </div>
                  )}

                  {geminiError && <p className="error-text-glow">❌ {geminiError}</p>}
                  
                  <button className="btn-secondary" onClick={resetSurvey} disabled={!hasRated} style={{ width: '100%', maxWidth: '360px', opacity: hasRated ? 1 : 0.4 }}>
                    Thực hiện lại đánh giá 🔄 {!hasRated && '🔒'}
                  </button>
                </div>
              </div>
            )}

            {geminiAdvice && (
              <GeminiAdvice 
                userInfo={userInfo} 
                resultLevel={resultData.result} 
                surveyAnswers={answers} 
                onBack={() => setStep(0)} 
                userCode={userCode}
              />
            )}
          </div>
        )}

      </main>
    </div>
  );
}

export default App;