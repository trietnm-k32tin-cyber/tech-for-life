import React, { useState, useEffect } from 'react';
import Chatbot from './Chatbot';

function GeminiAdvice({ userInfo, resultLevel, surveyAnswers, onBack, userCode }) {
  const [advice, setAdvice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [selectedStars, setSelectedStars] = useState(0);
  const [feedbackText, setFeedbackText] = useState('');
  const [hasSubmittedFeedback, setHasSubmittedFeedback] = useState(false);
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  useEffect(() => {
    if (!advice && userInfo && userInfo.name) {
      fetchGeminiAdvice();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchGeminiAdvice = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/gemini-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_code: userCode || null,
          name: userInfo?.name || 'Bạn',
          gender: userInfo?.gender || 'Nam',
          grade: userInfo?.grade || '11',
          hours: parseFloat(userInfo?.hours) || 0,
          result_level: resultLevel || 'Chưa có',
          survey_data: surveyAnswers || {}
        })
      });

      if (!res.ok) {
        throw new Error("Không thể kết nối với trí tuệ nhân tạo Gemini lúc này.");
      }

      const data = await res.json();
      setAdvice(data);
    } catch (err) {
      console.error(err);
      setError('Có lỗi xảy ra khi kết nối với AI. Bạn vui lòng thử lại nhé!');
    } finally {
      setLoading(false);
    }
  };

  const handleRatingSubmit = async (stars) => {
    if (hasSubmittedFeedback) return;
    
    setSelectedStars(stars);
    setSubmittingFeedback(true);

    const payload = {
      user_code: userCode || null,
      rating: stars,
      feedback_text: feedbackText.trim() || null,
      survey_data: {
        name: userInfo?.name,
        school: userInfo?.school,
        grade: userInfo?.grade,
        gender: userInfo?.gender,
        hours: parseFloat(userInfo?.hours) || 0,
        ...surveyAnswers
      },
      pred_class: resultLevel === 'Cao' ? 2 : (resultLevel === 'Trung bình' ? 1 : 0),
      total_score: Object.values(surveyAnswers || {}).reduce((a, b) => a + b, 0),
      advice_data: advice
    };

    try {
      await fetch('/api/save-training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      setHasSubmittedFeedback(true);
    } catch (e) {
      console.error("Lỗi gửi phản hồi:", e);
    } finally {
      setSubmittingFeedback(false);
    }
  };

  return (
    <div className="advice-container" style={{ position: 'relative', width: '100%', maxWidth: '850px', margin: '0 auto', background: 'transparent', boxShadow: 'none' }}>
      
      <button className="back-button" onClick={onBack} style={{ position: 'absolute', top: '10px', left: '10px', zIndex: 10 }}>
        ← Quay lại
      </button>

      <h2 style={{ textAlign: 'center', marginTop: '40px', color: 'var(--text-main)', fontSize: '1.8rem', fontWeight: '800' }}>
        Tư Vấn AI Chuyên Sâu
      </h2>

      {loading && (
        <div className="ai-loading-card text-center card" style={{ marginTop: '20px' }}>
          <div className="magic-spinner" style={{ fontSize: '3rem' }}>🔮</div>
          <p style={{ marginTop: '15px', fontWeight: 'bold' }}>AI đang phân tích sâu dữ liệu SHAP & RAG Y Khoa...</p>
        </div>
      )}

      {error && (
        <div className="error-message text-center card" style={{ marginTop: '20px' }}>
          <p style={{ color: '#e53e3e', fontWeight: 'bold', fontSize: '1.1rem' }}>❌ {error}</p>
          <button className="btn-primary" onClick={fetchGeminiAdvice} style={{ maxWidth: '200px', margin: '15px auto 0' }}>
            Thử lại 🔄
          </button>
        </div>
      )}

      {advice && !loading && (
        <div className="gemini-advice-container fade-in-up" style={{ marginTop: '25px' }}>
          <div className="ai-result-card-premium card" style={{ padding: 0, overflow: 'hidden' }}>
            
            <div className="ai-header-gradient panel-header-gradient">
              <h4>🧠 Góc Tư Vấn Chuyên Sâu Từ Gemini AI</h4>
              <span className="tech-badge">Model 2.5 Flash</span>
            </div>
            
            <div className="ai-body-content panel-scrollable-body">
              
              <div className="ai-dashboard-section">
                <h5>🔍 1. Phân Tích Xu Hướng Hành Vi</h5>
                <p className="ai-text-para">{advice.analysis}</p>
              </div>

              {advice.shap_root_causes && advice.shap_root_causes.length > 0 && (
                <div className="ai-dashboard-section">
                  <h5>⚡ 2. Nguyên Nhân Cốt Lõi (Phân Tích SHAP AI)</h5>
                  <ul className="premium-ai-list">
                    {advice.shap_root_causes.map((cause, idx) => (
                      <li key={idx}>
                        <span className="list-star-icon">🎯</span>
                        <p><strong>Tác nhân {idx + 1}:</strong> {cause}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {advice.medical_references && advice.medical_references.length > 0 && (
                <div className="ai-dashboard-section">
                  <h5>🏥 3. Căn Cứ & Hướng Dẫn Y Khoa Trích Xuất (RAG)</h5>
                  <div className="advice-box" style={{ background: 'rgba(6, 182, 212, 0.08)', borderColor: 'rgba(6, 182, 212, 0.3)' }}>
                    {advice.medical_references.map((refText, idx) => (
                      <p key={idx} style={{ margin: '8px 0', fontSize: '0.95rem', lineHeight: '1.6' }}>
                        📌 {refText}
                      </p>
                    ))}
                  </div>
                </div>
              )}

              <div className="ai-dashboard-section">
                <h5>🛠️ 4. Giải Pháp Cá Nhân Hóa Cho {userInfo?.name}</h5>
                <ul className="premium-ai-list">
                  {advice.solutions && advice.solutions.map((sol, index) => (
                    <li key={index}>
                      <span className="list-star-icon">⚡</span>
                      <p>{sol}</p>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="ai-dashboard-section">
                <h5>👨‍👩‍👧 5. Thông Điệp Gửi Tới Phụ Huynh</h5>
                <div className="premium-quote-box">
                  <span className="quote-icon-mark">“</span>
                  <p>{advice.parent_message}</p>
                </div>
              </div>

              <Chatbot />

              <div className="feedback-loop-section" style={{
                marginTop: '30px',
                padding: '20px',
                background: 'rgba(255, 255, 255, 0.05)',
                borderRadius: '16px',
                border: '1px solid rgba(150, 150, 150, 0.2)',
                textAlign: 'center'
              }}>
                <h5 style={{ color: 'var(--primary)', marginBottom: '8px', fontSize: '1.1rem' }}>
                  🌟 Đánh Giá & Giúp AI Học Hỏi
                </h5>
                <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '15px' }}>
                  Lời khuyên này có hữu ích với bạn không? Đánh giá của bạn sẽ giúp hệ thống tư vấn chuẩn hơn cho các bạn sau.
                </p>

                {!hasSubmittedFeedback && (
                  <div style={{ marginBottom: '15px' }}>
                    <input
                      type="text"
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      placeholder="Viết nhận xét hoặc góp ý ngắn (không bắt buộc)..."
                      style={{
                        width: '100%',
                        maxWidth: '450px',
                        padding: '10px 16px',
                        borderRadius: '10px',
                        border: '1px solid rgba(150,150,150,0.3)',
                        outline: 'none',
                        fontSize: '0.9rem',
                        background: 'rgba(255,255,255,0.8)',
                        color: '#000'
                      }}
                    />
                  </div>
                )}

                <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                  {[1, 2, 3, 4, 5].map((num) => (
                    <span
                      key={num}
                      style={{
                        fontSize: '2.2rem',
                        cursor: hasSubmittedFeedback ? 'default' : 'pointer',
                        color: (selectedStars >= num) ? '#fbbf24' : '#6b7280',
                        transition: 'transform 0.2s, color 0.2s',
                        transform: selectedStars >= num ? 'scale(1.15)' : 'scale(1)'
                      }}
                      onClick={() => handleRatingSubmit(num)}
                    >
                      ★
                    </span>
                  ))}
                </div>

                {submittingFeedback && <p style={{ fontSize: '0.85rem', color: 'var(--primary)', marginTop: '8px' }}>⏳ Đang ghi nhận phản hồi...</p>}
                {hasSubmittedFeedback && (
                  <p style={{ color: '#10b981', fontWeight: 'bold', marginTop: '10px', fontSize: '0.95rem' }}>
                    ✅ Cảm ơn bạn! Phản hồi đã được nạp vào hệ thống học tập của AI.
                  </p>
                )}
              </div>
              
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default GeminiAdvice;